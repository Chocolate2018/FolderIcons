# FolderIcon · iOS 桌面文件夹自定义图标

![FolderIcon](prefs/Resources/FolderIcon.png)

给越狱 iPhone 的桌面文件夹换图标：在「设置」里点一下文件夹 → 相册或「文件」里选一张图 → 立刻生效，随时一键还原。
纯视图层实现，不动图标模型，不改系统文件。

> 交付说明：本机是 iPhone 上的沙盒环境，没有 clang / Theos，**不能在这里编译出 .deb**。
> 这里给的是完整可编译的 Theos 工程源码，拿到电脑上 `make package` 即可。

---

## 一、先看调研：GitHub 上「桌面文件夹 / 文件夹图标」这一挂

按星标排序（2026-11-20 通过 GitHub API 抓取）：

| 项目 | 星标 | 干什么 | 这个插件借鉴了什么 |
|---|---:|---|---|
| [devblackops/Terminal-Icons](https://github.com/devblackops/Terminal-Icons) | 2 960 | 终端里按文件类型显示文件夹/文件图标 | 「图标按名称/类型匹配」的映射表思路 |
| [icon11-community/Folder11](https://github.com/icon11-community/Folder11) | 2 027 | Windows 11 风格文件夹图标集 | 图标素材的组织方式、留一套「默认回落」 |
| [lgarron/folderify](https://github.com/lgarron/folderify) | 1 954 | 给 macOS 文件夹生成像素级贴合原生风格的图标（CLI） | **关键**：图片要先裁切、再套原生圆角/曲率，否则一眼假 |
| [gfxholo/iconic](https://github.com/gfxholo/iconic) | 902 | Obsidian 里给任意条目（含文件夹）单独设图标 + 颜色，UI 内点选、即时生效 | **关键**：按「条目」粒度存映射、面板内选图、改完马上刷新 |
| [sameerasw/folder-icons](https://github.com/sameerasw/folder-icons) | 900 | Windows 11 风格文件夹图标包 | 命名规范（文件夹名 → 图标文件） |
| [PapirusDevelopmentTeam/papirus-folders](https://github.com/PapirusDevelopmentTeam/papirus-folders) | 818 | 一条命令换整套文件夹配色 | 「批量/重置」入口要显眼 |
| [Bengerthelorf/macIconChanger](https://github.com/Bengerthelorf/macIconChanger) | 656 | macOS 换 app/文件夹图标，GUI + CLI，可自动还原 | **关键**：非破坏性 + 可还原；否则用户不敢用 |
| [mklement0/fileicon](https://github.com/mklement0/fileicon) | 551 | macOS 命令行写自定义图标（资源叉） | 命令行兜底通道（这里做成了「丢文件进目录」） |
| [robb/FolderIconGenerator](https://github.com/robb/FolderIconGenerator) | 194 | SF Symbols → macOS 文件夹图标 | 统一画布尺寸、居中留白 |
| [jwilling/JWFolders](https://github.com/jwilling/JWFolders) | 635 | 老 iOS 上的文件夹视图实现 | 文件夹视图的层级结构、图标容器位置 |
| [kesai666/Desktop-folder](https://github.com/kesai666/Desktop-folder) | 4 | 在电脑桌面放一个「手机文件夹」小组件 | 桌面文件夹的交互隐喻 |

**看完这一圈得到的四条设计约束**（都落在实现里了）：

1. **非破坏性**。只替换视图绘制，不写 IconState、不替换包内资源，关掉开关/删掉配置即还原。
2. **按「文件夹名」做映射**，和 folderify / sameerasw 的「名称 → 图标」一致：用户能理解、能手动放文件。
3. **图片必须预处理**：居中裁切 + 等比填满 + 连续曲率圆角，否则贴到桌面上一眼是「贴纸」。
4. **改完立刻生效**。桌面插件最劝退的就是「改完要注销」。

顺带一提：越狱圈真正做「文件夹自定义图标」的插件大多是付费闭源的（Bolders 之类），
搜 `folder icon tweak` 能拿到的开源仓库基本只有老系统上的文件夹实现（JWFolders 那一代）。
所以这个轮子值得自己造一个，而且代码能自己改。

---

## 二、能做什么

- 任意桌面文件夹单独设图标，来源两条：**「文件」App**、或**粘贴剪贴板里的图片**（照片 App 长按拷贝即可）
  （相册入口已移除：`设置` 进程没有 PHPicker 素材的转换权限，任何 `load…Representation` 都会失败）
- 两种渲染：
  - **覆盖**：你的图铺满整个图标格子，隐藏原生的九宫格缩略图
  - **叠加**：保留系统文件夹底板，把图（可缩放）叠在上面，适合「文件夹 + 角标 logo」
- 圆角（0–0.5，连续曲率 `kCACornerCurveContinuous`）与图标大小（60%–100%）可调
- 改完即时生效（Darwin notification → SpringBoard 重绘），**不需要 respring**
- 左滑单个文件夹「恢复默认」，或一键全部恢复
- 高级通道：把 `游戏.png` 丢进 `/var/mobile/Library/FolderIcons/`，效果与面板选图完全一致（适合批量导入、脚本生成）
- 支持 rootful / rootless（Dopamine、palera1n rootless）

---

## 三、原理

```
设置.app                          SpringBoard
┌──────────────────────┐         ┌───────────────────────────────┐
│ FolderIconsPrefs     │         │ FolderIcon.dylib              │
│  • 列文件夹           │  CFPref │  • 读 Icons 字典（带内存缓存） │
│  • PHPicker 选图      │ ──────► │  • Hook SBFolderIconView       │
│  • 裁切 → 360px PNG   │  通知   │    - layoutSubviews            │
│  • 存进偏好域         │ ──────► │    - didMoveToWindow           │
└──────────────────────┘ notify  │    - setIcon:                  │
                                  │  • 叠加/隐藏原生图层            │
偏好域 com.dsh.foldericon          └───────────────────────────────┘
  Enabled / Mode / Scale / Radius
  Icons   = { "文件夹名" : PNG数据 }
  Folders = [ 发现过的文件夹名 ]
```

三个关键技术点：

1. **挂哪里**：桌面文件夹图标的视图类是 `SBFolderIconView`（`SBIconView` 的子类）。
   它每次布局都会走 `-layoutSubviews`，图标换绑会走 `-setIcon:`，这两处是最稳的注入点。
2. **怎么拿到文件夹名**：`view.icon.displayName`，取不到就退到 `view.icon.folder.displayName`。
   全程 KVC + `@try`，不引 SpringBoard 私有头，所以工程零私有 header 依赖。
3. **怎么替换**：往 `SBFolderIconView` 上插一个自己的 `UIImageView`（tag 固定，便于识别/复用），
   位置取原生 `iconImageView` 的 frame（**不是 view.bounds**——bounds 含文字标签区域，直接用会把文件夹名盖住）。
   覆盖模式下把原生 `iconImageView` / `backgroundView` 的 `hidden` 置 YES，移除图标时全部还原。

---

## 四、目录结构

```
FolderIcon/
├── Makefile                    # 主工程（tweak + 子工程 prefs）
├── control                     # Debian 包信息
├── Tweak.xm                    # 插件本体（SBFolderIconView 挂钩 + 渲染）
├── layout/…/FolderIcons.plist  # PreferenceLoader 入口（设置里那一行）
├── .github/workflows/build.yml # GitHub Actions 云编译（iPad 也能出包）
├── prefs/
│   ├── Makefile                # PreferenceBundle 子工程
│   ├── FolderIconsPrefs.mm     # 设置面板（纯 UIKit，不依赖 Preferences 私有头）
│   └── Resources/
│       ├── Info.plist          # Bundle 元信息，NSPrincipalClass 指向面板控制器
│       └── FolderIcon.png      # 设置里那一行的小图标（87×87，脚本生成）
├── docs/github-research.md     # 调研原始记录
├── docs/build-on-ipad.md       # iPad / 无电脑环境下的编译方案
└── README.md
```

---

## 五、编译与安装

需要一台电脑：macOS（或 Linux）+ [Theos](https://theos.dev) + iOS SDK。

> **只有 iPad、没有电脑？** 走云端编译：见 [docs/build-on-ipad.md](docs/build-on-ipad.md)。
> 工程里已内置工作流 [.github/workflows/build.yml](.github/workflows/build.yml)，
> 在 GitHub 上点一下 Run workflow，就能拿到 rootless + rootful 两个 `.deb`，全程只用 iPad 浏览器。

```bash
# 1. 把 FolderIcon 整个目录拷到电脑
export THEOS=~/theos

# 2. rootless（Dopamine / palera1n rootless，iOS 15+ 常见）
cd FolderIcon
make package

# 3. rootful（传统越狱）
make clean && make package THEOS_PACKAGE_SCHEME=

# 4. 产物
ls packages/*.deb
```

安装：

```bash
# 手机已装 OpenSSH，且电脑能 ssh 到手机
make install            # 编译 + 安装 + 自动 killall SpringBoard
# 或者
scp packages/com.dsh.foldericon_1.0.0_iphoneos-arm64.deb root@<手机IP>:/tmp/
ssh root@<手机IP> "dpkg -i /tmp/com.dsh.foldericon_*.deb && killall -9 SpringBoard"
```

> 架构字段：rootful 打包若 dpkg 报架构不符，把 `control` 里的 `Architecture: iphoneos-arm64` 改成 `iphoneos-arm`。
> 依赖字段：`mobilesubstrate | ellekit` 二选一，rootless 环境（ElleKit）也能满足。

安装后 `SpringBoard` 会自动重启一次；进「设置」往下翻，能看到「文件夹图标」。

---

## 六、使用

1. 设置 → 文件夹图标 → 打开开关（默认开着）。
2. 「文件夹」列表里点一个文件夹 → 选来源（「文件」/ 剪贴板）→ 选图 → 立刻生效，回桌面看。
   照片来源：照片 App 长按照片 → 拷贝 → 面板里「粘贴剪贴板里的图片」。
3. 不满意：「覆盖 / 叠加」切换，或用「图标大小 / 圆角」微调。
4. 单个还原：列表里左滑该文件夹 → 恢复默认。
5. 全部还原：维护 → 全部恢复默认。

**批量/脚本导入**（适合一次配几十个）：

```bash
# 电脑上生成 360×360 的 PNG，文件名 = 桌面上的文件夹名
scp 游戏.png 工具.png root@<手机IP>:/var/mobile/Library/FolderIcons/
ssh root@<手机IP> "chown -R mobile:mobile /var/mobile/Library/FolderIcons && killall -9 SpringBoard"
```

面板只要求「文件名去掉 .png」与文件夹显示名完全一致（区分大小写、包含空格与中文）。

---

## 七、数据存放

| 键 / 路径 | 内容 |
|---|---|
| `/var/mobile/Library/Preferences/com.dsh.foldericon.plist` | `Enabled`、`Mode`、`Scale`、`Radius`、`Icons`（文件夹名 → PNG 数据）、`Folders`（发现过的名字） |
| `/var/mobile/Library/FolderIcons/*.png` | 可选兜底目录，与偏好数据等价，优先读偏好 |

卸载插件不会动系统图标，但建议先「全部恢复默认」再卸载，避免残留偏好（残留也只是占几十 KB）。

---

## 八、兼容性与已知限制

- 目标 iOS 14–16；iOS 17/18 大概率可用但未验证。`SBFolderIconView` 不存在时会自动退到
  `SBIconView` 兜底挂钩（按 icon 类名里是否带 `Folder` 判断）。
- 按「文件夹显示名」索引：**给文件夹改名后需要重新设置**；同名文件夹会共用一张图。
- 只影响桌面上的文件夹图标，不影响「打开文件夹后」的九宫格内容。
- 图标数据存在偏好 plist 里，单张 360px PNG 通常 30–120 KB，几十个文件夹没问题；上百个建议改用文件目录方案。
- 不做 Dock 文件夹、不做 App 资源库里的文件夹图标（系统那里用的是另一套视图）。

---

## 九、排错

**1. 设置里没有入口**
`PreferenceLoader` 是否安装？bundle 是否落到 `/Library/PreferenceBundles/`（rootless 是 `/var/jb/Library/PreferenceBundles/`）？
装完执行 `killall -9 Preferences` 重开设置。

**2. 桌面图标完全没变化**
先打开「外观 → 记录调试日志」，然后：

```bash
log stream --predicate 'eventMessage CONTAINS "FolderIcon"'
```

- 有「新建叠加层」日志但看不到图 → 叠加层被原生图层盖住了，把「渲染模式」切「覆盖」。
- 一条日志都没有 → 当前系统的类名不是 `SBFolderIconView`。用 `frida`/`cycript` 在 SpringBoard 里
  `Object.keys(...)` 查一下文件夹图标的真实类名，然后改 `Tweak.xm` 里的 `%hook` 与
  `CFIWalkViews` 里的 `objc_getClass("SBFolderIconView")` 两处。

**3. 图标显示但「九宫格」还压在上面**
某些版本的原生图层不叫 `iconImageView`。在 `CFINativeIconView()` 的 `keys` 数组里加一个候选
（比如 `@"_iconImageView"`、`@"iconImageView"` 之外的自定义 key），或用调试日志把
`view.subviews` 的类名打出来再补。

**4. 改完要切一下页面才生效**
正常现象：`notify_post` 会重绘已存在的视图，但系统新建的图标视图要等下次布局；
切页/滑动一次即全部正确。这也是为什么面板里留了「立即刷新桌面图标」。

**5. 图标发灰/半透明**
你的 PNG 带 alpha，而「覆盖」模式把原生底板藏了。换不透明图，或用「叠加」模式。

**6. 白图标**
PNG 转换失败或数据过大。面板已经统一转成 360×360、8bit PNG；若仍白，检查偏好 plist 里 `Icons` 对应值是否为空。

---

## 十、路线图（想做但没做）

- 按文件夹「标识符」而不是显示名索引（需要读 IconState 的 folder id，改名不再失效）
- 从「文件」App 直接导入（UIDocumentPicker），免 Filza
- 图标缓存预渲染（把圆角烤进位图，省掉每帧 `cornerRadius`）
- 导入 `.theme` 图标包，按 App 名自动分配
- 给 Dock 文件夹、App 资源库文件夹做适配

---

## 许可

MIT，见 [LICENSE](LICENSE)。

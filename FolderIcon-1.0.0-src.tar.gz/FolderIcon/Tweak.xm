//
//  Tweak.xm
//  FolderIcon — 为 iOS 桌面文件夹设置自定义图标
//
//  挂钩点：SBFolderIconView（桌面上的「文件夹」图标视图）
//  数据源：com.dsh.foldericon 偏好域里的 Icons 字典 { 文件夹名 : PNG 数据 }
//          以及可选的兜底目录 /var/mobile/Library/FolderIcons/<文件夹名>.png
//
//  设计原则：
//    1. 不修改 SpringBoard 的图标模型，只在视图层叠加/替换绘制，随时可无损还原。
//    2. 只用运行时 + KVC 访问私有方法，不依赖 SpringBoard 私有头文件，编译成功率更高。
//    3. 每次布局都走「快速失败」路径：没配置图标时只做一次字典查询。
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <notify.h>
#import <objc/runtime.h>

#define CFI_DOMAIN             CFSTR("com.dsh.foldericon")
#define CFI_NOTIFY_RELOAD      "com.dsh.foldericon/reload"
#define CFI_NOTIFY_FOLDERS     "com.dsh.foldericon/folders"

// 叠加视图的 tag，用于识别「这是我自己加的」
static const NSInteger kCFIOverlayTag = 0x46434931; // 'FCI1'

// 兜底目录：用 Filza 等工具放图，文件名 = 文件夹显示名
static NSString *const kCFIImageDir = @"/var/mobile/Library/FolderIcons";

#pragma mark - 被 hook 类的最小声明

// 关键：必须让编译器知道这两个类的父类是 UIView。
// 否则 Logos 生成的 `self` 类型是 `SBFolderIconView *const __unsafe_unretained`，
// 和 UIView * 没有任何继承关系，ARC 下传给 CFIApplyToView(UIView *) 会报
// "no matching function for call"。
// 这里只是编译期声明，不引入任何私有头文件，也不影响运行时。
@interface SBIconView : UIView @end
@interface SBFolderIconView : SBIconView @end

#pragma mark - 运行时状态

static NSDictionary<NSString *, NSData *> *gIcons = nil;
static BOOL      gEnabled   = YES;
static NSInteger gMode      = 0;        // 0 = 覆盖（隐藏原生九宫格）  1 = 叠加（保留原生底）
static CGFloat   gScale     = 1.0;      // 0.4 ~ 1.0
static CGFloat   gRadius    = 0.2237;   // 相对宽度，0 ~ 0.5
static BOOL      gDebug     = NO;
static BOOL      gHasImageDir = NO;

static NSCache<NSString *, UIImage *> *gImageCache = nil;
static NSMutableSet<NSString *> *gPublished = nil;

#pragma mark - 偏好读取

static id CFICopyPref(CFStringRef key) {
    return (__bridge_transfer id)CFPreferencesCopyAppValue(key, CFI_DOMAIN);
}

static void CFILoadPreferences(void) {
    CFPreferencesAppSynchronize(CFI_DOMAIN);

    id icons = CFICopyPref(CFSTR("Icons"));
    gIcons = [icons isKindOfClass:[NSDictionary class]] ? (NSDictionary *)icons : @{};

    id v = CFICopyPref(CFSTR("Enabled"));
    gEnabled = v ? [v boolValue] : YES;

    v = CFICopyPref(CFSTR("Mode"));
    gMode = v ? [v integerValue] : 0;
    if (gMode < 0 || gMode > 1) gMode = 0;

    v = CFICopyPref(CFSTR("Scale"));
    gScale = v ? [v doubleValue] : 1.0;
    if (!(gScale >= 0.4 && gScale <= 1.0)) gScale = 1.0;

    v = CFICopyPref(CFSTR("Radius"));
    gRadius = v ? [v doubleValue] : 0.2237;
    if (!(gRadius >= 0.0 && gRadius <= 0.5)) gRadius = 0.2237;

    v = CFICopyPref(CFSTR("Debug"));
    gDebug = v ? [v boolValue] : NO;

    gHasImageDir = [[NSFileManager defaultManager] fileExistsAtPath:kCFIImageDir];
    [gImageCache removeAllObjects];
}

#pragma mark - 图标查找

static NSString *CFISanitizeName(NSString *name) {
    if (name.length == 0) return @"";
    NSMutableString *s = [name mutableCopy];
    NSArray<NSString *> *bad = @[@"/", @":", @"\0"];
    for (NSString *b in bad) {
        [s replaceOccurrencesOfString:b withString:@"_" options:0 range:NSMakeRange(0, s.length)];
    }
    return s;
}

static UIImage *CFIImageForFolder(NSString *name) {
    if (name.length == 0) return nil;

    UIImage *cached = [gImageCache objectForKey:name];
    if (cached) return cached;

    UIImage *image = nil;
    id data = gIcons[name];
    if ([data isKindOfClass:[NSData class]] && [(NSData *)data length] > 0) {
        image = [UIImage imageWithData:(NSData *)data scale:[UIScreen mainScreen].scale];
    }

    // 兜底：文件目录里的同名 PNG
    if (!image && gHasImageDir) {
        NSString *file = [kCFIImageDir stringByAppendingPathComponent:
                          [CFISanitizeName(name) stringByAppendingPathExtension:@"png"]];
        image = [UIImage imageWithContentsOfFile:file];
    }

    if (image) [gImageCache setObject:image forKey:name];
    return image;
}

#pragma mark - 视图 introspection

/// 从 SBFolderIconView 取出文件夹显示名（用 KVC，避免私有头文件依赖）
static NSString *CFIFolderNameForView(UIView *view) {
    id icon = nil;
    @try {
        icon = [view valueForKey:@"icon"];
    } @catch (__unused NSException *e) {}

    if (!icon) return nil;

    NSString *name = nil;
    @try {
        id dn = [icon valueForKey:@"displayName"];
        if ([dn isKindOfClass:[NSString class]]) name = dn;
    } @catch (__unused NSException *e) {}

    if (name.length == 0) {
        id folder = nil;
        @try {
            folder = [icon valueForKey:@"folder"];
        } @catch (__unused NSException *e) {}
        @try {
            id dn = [folder valueForKey:@"displayName"];
            if ([dn isKindOfClass:[NSString class]]) name = dn;
        } @catch (__unused NSException *e) {}
    }

    return name.length ? name : nil;
}

/// 原生的「图标图像视图」（文件夹的九宫格缩略图默认画在它里面）
static UIView *CFINativeIconView(UIView *view) {
    NSArray<NSString *> *keys = @[@"iconImageView", @"_iconImageView"];
    for (NSString *key in keys) {
        @try {
            id v = [view valueForKey:key];
            if ([v isKindOfClass:[UIView class]] && [(UIView *)v tag] != kCFIOverlayTag) {
                return (UIView *)v;
            }
        } @catch (__unused NSException *e) {}
    }
    return nil;
}

/// 原生文件夹「底板」（某些系统版本上是独立视图）
static UIView *CFINativeBackgroundView(UIView *view) {
    NSArray<NSString *> *keys = @[@"backgroundView", @"_backgroundView"];
    for (NSString *key in keys) {
        @try {
            id v = [view valueForKey:key];
            if ([v isKindOfClass:[UIView class]] && [(UIView *)v tag] != kCFIOverlayTag) {
                return (UIView *)v;
            }
        } @catch (__unused NSException *e) {}
    }
    return nil;
}

/// 把发现过的文件夹名回写给设置面板，让面板即使读不到 IconState 也能列出文件夹
static void CFIPublishFolderName(NSString *name) {
    if (name.length == 0 || [gPublished containsObject:name]) return;
    [gPublished addObject:name];

    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        id existing = CFICopyPref(CFSTR("Folders"));
        NSMutableArray *list = [existing isKindOfClass:[NSArray class]]
            ? [(NSArray *)existing mutableCopy]
            : [NSMutableArray array];
        if ([list containsObject:name]) return;
        [list addObject:name];
        CFPreferencesSetAppValue(CFSTR("Folders"), (__bridge CFPropertyListRef)list, CFI_DOMAIN);
        CFPreferencesAppSynchronize(CFI_DOMAIN);
        notify_post(CFI_NOTIFY_FOLDERS);
    });
}

#pragma mark - 绘制

/// 点击文件夹时临时关闭叠加层的时间窗。
/// 系统打开文件夹时会把整个 SBFolderIconView 放大，叠加层如果还在，
/// 就会看到「自定义图标跟着放大再消失」。所以按下瞬间就撤掉叠加层、
/// 把原生外观还回去，放大过程就是系统原本的文件夹动画。
static CFAbsoluteTime gCFISuppressUntil = 0;

static BOOL CFIIsSuppressed(void) {
    return CFAbsoluteTimeGetCurrent() < gCFISuppressUntil;
}

/// 移除叠加层并把原生图层恢复可见（关闭开关、清空图标、还原时都会走到）
static void CFIClearOverlay(UIView *view) {
    UIView *old = [view viewWithTag:kCFIOverlayTag];
    if (old) [old removeFromSuperview];

    UIView *nativeIcon = CFINativeIconView(view);
    if (nativeIcon) nativeIcon.hidden = NO;

    UIView *nativeBack = CFINativeBackgroundView(view);
    if (nativeBack) nativeBack.hidden = NO;
}

#pragma mark - 打开文件夹时先撤掉叠加层

static void CFIApplyToView(UIView *view);

/// 按下 / 打开文件夹时调用：立刻还原原生外观，并压住 1.5 秒重建。
/// 注意：这里不挂任何手势。手势会和系统自己的点按识别器冲突，
/// 导致点了文件夹打不开（上一版就是这么坏掉的）。
static void CFIBeginSuppression(UIView *view) {
    gCFISuppressUntil = CFAbsoluteTimeGetCurrent() + 1.5;
    if (view) CFIClearOverlay(view);

    __weak UIView *weakView = view;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.3 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        gCFISuppressUntil = 0;
        UIView *strongView = weakView;
        if (strongView) CFIApplyToView(strongView);
    });
}

static void CFIApplyToView(UIView *view) {
    if (!view) return;

    // 快速失败：没启用、或一条配置都没有时，直接清理并返回，
    // 避免整屏图标反复做 KVC
    if (!gEnabled || (gIcons.count == 0 && !gHasImageDir)) {
        CFIClearOverlay(view);
        return;
    }

    // 正在打开文件夹（或刚按下）→ 先保持原生外观，别让叠加层参与放大动画
    if (CFIIsSuppressed()) {
        CFIClearOverlay(view);
        return;
    }

    NSString *name = CFIFolderNameForView(view);
    if (!name) return;
    CFIPublishFolderName(name);

    UIImage *image = CFIImageForFolder(name);

    UIView *nativeIcon = CFINativeIconView(view);
    UIView *nativeBack = CFINativeBackgroundView(view);
    UIImageView *overlay = (UIImageView *)[view viewWithTag:kCFIOverlayTag];

    // 没有自定义图标 → 还原
    if (!image) {
        if (overlay) [overlay removeFromSuperview];
        if (nativeIcon) nativeIcon.hidden = NO;
        if (nativeBack) nativeBack.hidden = NO;
        return;
    }

    // 计算图标区域：优先用原生图像视图的位置（不含文字标签）
    CGRect rect = CGRectZero;
    if (nativeIcon) {
        UIView *host = nativeIcon.superview ?: view;
        rect = [host convertRect:nativeIcon.frame toView:view];
    }
    if (CGRectIsEmpty(rect) || rect.size.width < 4.0) {
        CGFloat side = MIN(view.bounds.size.width, view.bounds.size.height);
        rect = CGRectMake((view.bounds.size.width - side) * 0.5, 0, side, side);
    }

    if (gScale < 1.0) {
        CGFloat dx = rect.size.width * (1.0 - gScale) * 0.5;
        CGFloat dy = rect.size.height * (1.0 - gScale) * 0.5;
        rect = CGRectInset(rect, dx, dy);
    }

    if (!overlay) {
        overlay = [[UIImageView alloc] initWithFrame:rect];
        overlay.tag = kCFIOverlayTag;
        overlay.userInteractionEnabled = NO;
        overlay.contentMode = UIViewContentModeScaleAspectFill;
        overlay.clipsToBounds = YES;
        overlay.backgroundColor = [UIColor clearColor];
        overlay.opaque = NO;
        overlay.autoresizingMask = UIViewAutoresizingNone;

        // 插到原生图像之上、角标之下，尽量不挡系统的角标/高亮层
        id badge = nil;
        @try { badge = [view valueForKey:@"badgeView"]; } @catch (__unused NSException *e) {}
        if ([badge isKindOfClass:[UIView class]] && [(UIView *)badge superview] == view) {
            [view insertSubview:overlay belowSubview:(UIView *)badge];
        } else if (nativeIcon && nativeIcon.superview == view) {
            [view insertSubview:overlay aboveSubview:nativeIcon];
        } else {
            [view addSubview:overlay];
        }

        if (gDebug) {
            NSLog(@"[FolderIcon] 新建叠加层 folder=%@ rect=%@", name, NSStringFromCGRect(rect));
        }
    }

    overlay.frame = rect;
    overlay.image = image;

    CGFloat radius = MIN(rect.size.width, rect.size.height) * gRadius;
    overlay.layer.cornerRadius = radius;
    if (@available(iOS 13.0, *)) {
        overlay.layer.cornerCurve = kCACornerCurveContinuous;
    }

    // 覆盖模式隐藏原生九宫格与底板；叠加模式保留
    BOOL hideNative = (gMode == 0);
    if (nativeIcon) nativeIcon.hidden = hideNative;
    if (nativeBack) nativeBack.hidden = hideNative;
}

#pragma mark - 识别文件夹图标视图

/// 是否「桌面文件夹图标视图」。
/// 首选 SBFolderIconView；如果系统改了类名（iOS 17/18 未验证），
/// 退化成「SBIconView 且 icon 的类名里带 Folder」的判断。
static BOOL CFIIsFolderIconView(UIView *view) {
    static Class folderViewClass = Nil;
    static Class iconViewClass   = Nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        folderViewClass = objc_getClass("SBFolderIconView");
        iconViewClass   = objc_getClass("SBIconView");
    });

    if (folderViewClass && [view isKindOfClass:folderViewClass]) return YES;

    if (iconViewClass && [view isKindOfClass:iconViewClass]) {
        id icon = nil;
        @try { icon = [view valueForKey:@"icon"]; } @catch (__unused NSException *e) {}
        if (icon) {
            NSString *className = NSStringFromClass([icon class]);
            if ([className rangeOfString:@"Folder"].location != NSNotFound) return YES;
        }
    }
    return NO;
}

#pragma mark - 全屏刷新

static void CFIWalkViews(UIView *view) {
    if (CFIIsFolderIconView(view)) {
        CFIApplyToView(view);
    }
    NSArray<UIView *> *subviews = view.subviews; // 拷贝一份，避免遍历中被修改
    for (UIView *sub in subviews) {
        CFIWalkViews(sub);
    }
}

static void CFIReloadAllViews(void) {
    for (UIWindow *window in [UIApplication sharedApplication].windows) {
        CFIWalkViews(window);
    }
}

#pragma mark - Hooks

%group FolderIcons

%hook SBFolderIconView

- (void)layoutSubviews {
    %orig;
    CFIApplyToView((UIView *)self);
}

- (void)didMoveToWindow {
    %orig;
    CFIApplyToView((UIView *)self);
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    // 手指抬起 = 点按完成，系统紧接着才开始放大动画；
    // 先撤叠加层再放行 %orig，保证动画首帧就是原生外观。
    // 用 touchesEnded 而不是 touchesBegan：桌面滑动时手指按下会被系统取消，不会误伤。
    if (gDebug) NSLog(@"[FolderIcon] 文件夹图标点击结束，撤掉叠加层");
    CFIBeginSuppression((UIView *)self);
    %orig;
}
- (void)setIcon:(id)icon {
    %orig;
    CFIApplyToView((UIView *)self);
}

%end

%end // FolderIcons

/// 只负责「按下时先撤掉叠加层」。
/// setHighlighted: 在个别系统版本上可能不存在，所以先做运行期检查再安装，
/// 避免 %orig 打到空指针（那会直接把 SpringBoard 干掉）。
%group HighlightHooks

%hook SBFolderIconView

- (void)setHighlighted:(BOOL)highlighted {
    %orig;
    if (!highlighted) return;
    if (gDebug) NSLog(@"[FolderIcon] 文件夹图标被按下，撤掉叠加层");
    CFIBeginSuppression((UIView *)self);
}

%end

%end // HighlightHooks

/// 兜底：哪天 SBFolderIconView 不存在了，仍能从 SBIconView 这一层抓住文件夹图标
%group FallbackIcons

%hook SBIconView

- (void)setIcon:(id)icon {
    %orig;
    if (CFIIsFolderIconView((UIView *)self)) CFIApplyToView((UIView *)self);
}

- (void)didMoveToWindow {
    %orig;
    if (CFIIsFolderIconView((UIView *)self)) CFIApplyToView((UIView *)self);
}

%end

%end // FallbackIcons

#pragma mark - 初始化

%ctor {
    @autoreleasepool {
        gImageCache = [[NSCache alloc] init];
        gImageCache.countLimit = 64;
        gPublished = [NSMutableSet set];

        CFILoadPreferences();

        if (objc_getClass("SBFolderIconView")) {
            %init(FolderIcons);
        } else {
            NSLog(@"[FolderIcon] 未找到 SBFolderIconView，改用 SBIconView 兜底挂钩");
        }

        if (objc_getClass("SBFolderIconView") &&
            class_getInstanceMethod(objc_getClass("SBFolderIconView"), @selector(setHighlighted:))) {
            %init(HighlightHooks);
        } else {
            NSLog(@"[FolderIcon] 当前系统没有 setHighlighted:，跳过「按下即撤」");
        }

        if (objc_getClass("SBIconView")) {
            %init(FallbackIcons);
        }

        // 设置面板改完配置后通知 SpringBoard 即时刷新，无需 respring
        static int reloadToken = 0;
        notify_register_dispatch(CFI_NOTIFY_RELOAD, &reloadToken, dispatch_get_main_queue(), ^(int token) {
            CFILoadPreferences();
            CFIReloadAllViews();
        });

        if (gDebug) {
            NSLog(@"[FolderIcon] 已加载，%lu 个自定义图标", (unsigned long)gIcons.count);
        }
    }
}

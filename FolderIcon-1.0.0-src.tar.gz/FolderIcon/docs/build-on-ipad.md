# 在 iPad 上编译 FolderIcon

先说结论：**Theos 官方只支持 macOS / Linux 作为编译宿主，iPadOS 不是受支持的宿主。**
所以在 iPad 上有三条路，按推荐度排：

| 方案 | 需要什么 | 体验 |
|---|---|---|
| **A. GitHub Actions 云编译** | 只要 iPad 浏览器 + GitHub 账号 | 推荐。3 分钟出 `.deb`，全程不碰电脑 |
| **B. 远程 Mac / Linux** | 一台开机的电脑（同局域网或公网） | 最省心，但要电脑 |
| **C. iPad 本机装 Theos** | 已越狱 + NewTerm + clang/SDK/ldid | 不推荐，坑很深 |

---

## 方案 A：GitHub Actions 云编译（全程只用 iPad）

原理：GitHub 给你一台 Ubuntu 机器，装好 Theos + iOS SDK，把你的源码 `make package` 成 `.deb`，然后打包成 artifact 让你下载。
工程里已经内置了工作流：[`.github/workflows/build.yml`](../.github/workflows/build.yml)，一次跑出 **rootless + rootful 两个包**。

### A1. 建仓库

Safari 打开 <https://github.com/new> → 填名字（比如 `FolderIcon`）→ Public 或 Private 都行（Private 每月 2000 分钟免费额度，这个项目一次约 3 分钟）→ **Create repository**。

### A2. 把源码传上去（二选一）

**方式 1：只传 tar.gz（最省事）**

1. 仓库首页 → **Add file → Upload files**
2. 选「文件」App 里的 `FolderIcon-1.0.0-src.tar.gz`
3. **Commit changes**

> 说明：Safari 上传不支持整个文件夹，所以这里走「一个压缩包 + 工作流自动解压」。
> 工作流里已经写了：根目录没有 `FolderIcon/` 但存在 `*.tar.gz` 时会自动 `tar xzf`。

**方式 2：保留目录结构（以后要改代码就选这个）**

装一个 **iSH**（App Store 免费，Alpine Linux 环境），然后在 iSH 里：

```sh
apk add git
git clone https://<你的token>@github.com/<你的用户名>/FolderIcon.git
cd FolderIcon
# 把解压出来的 12 个文件 + .github/ 拷进来
git add -A && git commit -m "init" && git push
```

token 在 GitHub → Settings → Developer settings → Personal access tokens → Fine-grained tokens 生成，勾选这个仓库的 **Contents: Read and write**。

> 缺点：iSH 是 x86 模拟，慢；优点：能保留 `.github/`，不用再手动建工作流文件。

### A3. 加工作流文件（用方式 1 的必做）

仓库首页 → **Add file → Create new file** → 文件名直接填：

```
.github/workflows/build.yml
```

GitHub 会自己建目录。把下面「附：build.yml 全文」粘进去 → **Commit changes**。

（用方式 2 的可以跳过：tar 包里已经带了这份文件。）

> 如果你已经照上一版跑过一次、两个 job 都红了：先看「常见问题」第一条，那是 `theos-dir` 的相对路径问题，改两行即可。

### A4. 跑一次

仓库首页 → **Actions** → 左侧 **Build FolderIcon** → 右侧 **Run workflow** → 分支 `main` → **Run workflow**。

- 第一次约 3–5 分钟（要下 Theos + SDK）
- 之后有缓存，约 1–2 分钟
- 两个 job（`rootless`、`rootful`）并行

### A5. 下载 `.deb`

跑完点进这次 run → 滑到页面底部 **Artifacts**：

- `deb-rootless` → 给 Dopamine / palera1n rootless 用
- `deb-rootful` → 给传统越狱用

点一下会下载一个 zip（Safari 会存到「文件 → 下载」），在「文件」App 里点一下解压，得到：

```
com.dsh.foldericon_1.0.0_iphoneos-arm64.deb
```

### A6. 安装

- **Sileo / Zebra**：找到本地包 / 已下载，点开安装
- **Filza**：定位到 `.deb` → 点它 → Install（Filza 内置 dpkg）
- **NewTerm**：

```sh
cd /var/mobile/Downloads
dpkg -i com.dsh.foldericon_1.0.0_iphoneos-arm64.deb
killall -9 SpringBoard
```

装完进「设置」，往下翻到「文件夹图标」。

---

## 方案 B：远程 Mac / Linux

iPad 上装 **Termius** 或 **Blink Shell**，SSH 到电脑：

```sh
export THEOS=~/theos
cd FolderIcon
make package THEOS_PACKAGE_SCHEME=rootless     # 产出 packages/*.deb
```

如果电脑和手机在同一局域网，还能一步装到设备：

```sh
make install THEOS_DEVICE_IP=192.168.1.23
```

`.deb` 想拿回 iPad：`scp` 到 iCloud Drive，或者直接在电脑上 `python3 -m http.server` 开个临时下载页，iPad Safari 下。

---

## 方案 C：iPad 本机装 Theos（不推荐）

**为什么劝退：**

1. Theos 上游只支持 macOS / Linux 宿主，iOS 不在支持列表里；
2. 网上那套「Cydia 装 iOS toolchain + `installtheos3`」的教程是 **2016 年 iOS 9 + 32 位** 时代的，和今天的 iOS 15/16 rootless 环境对不上（路径从 `/` 变成了 `/var/jb`，签名机制也变了）；
3. 你需要一次性凑齐：clang、ldid、perl、iOS SDK，缺一个就报错，而且报错信息通常指向别处；
4. 就算编出 `.dylib`，还要自己处理 rootless 签名与安装路径。

**如果坚持要试**，最小路径：

```sh
# 1. 越狱 iPad 上装 NewTerm 3
# 2. 装 clang / llvm（Procursus 源里包名可能是 clang、llvm-13 等）
# 3. 拉 Theos
git clone --recursive https://github.com/theos/theos.git /var/theos
export THEOS=/var/theos
# 4. 放 SDK
#    需要 iPhoneOS SDK，放到 $THEOS/sdks/ 下
# 5. 给编译器签名
ldid -s "$(command -v clang)"
# 6. 编译（只用 arm64，避免 arm64e 的 clang 问题）
make package THEOS_PACKAGE_SCHEME=rootless ARCHS=arm64
```

预期：卡在 toolchain / SDK / ldid 其中之一。这条路更适合「就想折腾」的人。

---

## 附：build.yml 全文

仓库里的文件是 [`.github/workflows/build.yml`](../.github/workflows/build.yml)，下面这份和它一致：

```yaml
name: Build FolderIcon

# 纯云端编译：不需要 Mac，也不需要越狱设备上的工具链。
on:
  push:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    strategy:
      fail-fast: false
      matrix:
        # rootless：Dopamine / palera1n rootless（iOS 15+ 主流）
        # rootful ：传统越狱
        scheme: [rootless, rootful]

    steps:
      - name: 取出仓库
        uses: actions/checkout@v4

      - name: 解压源码（仓库里只有 tar.gz 时）
        run: |
          if [ ! -d FolderIcon ]; then
            for f in ./*.tar.gz; do
              [ -f "$f" ] && tar xzf "$f"
            done
          fi
          if [ ! -f FolderIcon/Makefile ]; then
            echo "::error::找不到 FolderIcon/Makefile，源码层级不对"
            exit 1
          fi
          echo "源码就绪："
          ls FolderIcon

      # 可选：允许在仓库根目录放「单文件覆盖」，省得每次改一行都要重传整个 tar.gz。
      # 例如把 Tweak.xm 上传到仓库根目录，这里会自动覆盖解压出来的那份。
      - name: 应用根目录的单文件覆盖
        run: |
          for f in Tweak.xm Makefile control FolderIcon.plist; do
            if [ -f "$f" ]; then
              echo "覆盖 FolderIcon/$f"
              cp -f "$f" "FolderIcon/$f"
            fi
          done

      - name: 缓存 Theos 与 SDK
        uses: actions/cache@v4
        with:
          path: ${{ github.workspace }}/theos
          key: ${{ runner.os }}-theos-v2

      # ！重要：这里千万不要写 `with: theos-dir: theos`。
      # 该 action 会把环境变量 THEOS 设成你传进去的字符串；
      # 传相对路径 "theos" 后，make 在 FolderIcon/ 子目录里就变成了
      # FolderIcon/theos/... ，直接找不到 SDK 与 makefiles。
      # 不传参数时默认是 ${{ github.workspace }}/theos（绝对路径），才是对的。
      - name: 安装 Theos
        uses: Randomblock1/theos-action@v1

      - name: 环境自检
        run: |
          echo "THEOS=$THEOS"
          ls "$THEOS" | head -20
          echo "--- sdks ---"
          ls "$THEOS/sdks" | head -5

      - name: 编译（${{ matrix.scheme }}）
        run: |
          cd FolderIcon
          if [ "${{ matrix.scheme }}" = "rootful" ]; then
            sed -i 's/^Architecture:.*/Architecture: iphoneos-arm/' control
            FLAGS="THEOS_PACKAGE_SCHEME="
          else
            FLAGS="THEOS_PACKAGE_SCHEME=rootless"
          fi
          echo "make package FINALPACKAGE=1 $FLAGS"
          set +e
          make package FINALPACKAGE=1 $FLAGS 2>&1 | tee /tmp/build.log
          status=${PIPESTATUS[0]}
          echo "make exit = $status"
          echo "--- 日志最后 40 行 ---"
          tail -40 /tmp/build.log
          exit $status

      - name: 上传 deb
        uses: actions/upload-artifact@v4
        with:
          name: deb-${{ matrix.scheme }}
          path: FolderIcon/packages/*.deb
          if-no-files-found: warn

      - name: 失败时上传编译日志
        if: failure()
        uses: actions/upload-artifact@v4
        with:
          name: log-${{ matrix.scheme }}
          path: /tmp/build.log
          if-no-files-found: ignore
```

---

## 常见问题

**红叉但只显示 `Process completed with exit code 1`**
这一页只有汇总，真正的错误在 job 里：点进 `build (rootless)` → 展开红色步骤 → 页面底部就是报错内容。把最后 30 行发我即可。

**报 `No rule to make target 'theos/makefiles/common.mk'` 或 `theos/sdks` 找不到**
这就是第一版工作流的 bug：`安装 Theos` 那一步写了

```yaml
        with:
          theos-dir: theos
```

`theos-dir` 会被这个 action 原样写进环境变量 `THEOS`，于是 `THEOS=theos` 是**相对路径**；
编译时 `cd FolderIcon` 之后 `$(THEOS)` 变成了 `FolderIcon/theos`，自然找不到。

修法：把这两行删掉（默认值就是 `${{ github.workspace }}/theos` 绝对路径）。

**报 `Theos version mismatch! common.mk [version 0] loaded in tandem with rules.mk [version 1k]`**
`prefs/` 这类子工程是由 `aggregate.mk` 用**独立 make 进程**编译的，
它的 Makefile 必须自己再 `include` 一次 common.mk：

```make
include $(THEOS)/makefiles/common.mk

BUNDLE_NAME = FolderIconsPrefs
...
include $(THEOS_MAKE_PATH)/bundle.mk
```

**报 `no matching function for call to 'CFIApplyToView'`**
这是 ARC + Logos 的经典坑：`%hook` 里的 `self` 类型是 `SBFolderIconView *const __unsafe_unretained`，
如果文件里没有这个类的 `@interface` 声明，编译器就不知道它继承自 `UIView`，
传给 `(UIView *)` 参数直接报类型不匹配。

修法：在文件顶部补两行编译期声明（不引入私有头文件），调用处再加显式转换：

```objc
@interface SBIconView : UIView @end
@interface SBFolderIconView : SBIconView @end
```

**设置里报「未能载入软件包 … incompatible architecture (have 'arm64', need 'arm64e')」**
A12 及以上设备（含 iPhone 13 mini）的 SpringBoard 和「设置」都是 arm64e 进程，
纯 arm64 的 dylib 会被 dyld 拒绝加载。

工程里的 `Makefile` 用了 `override ARCHS := arm64 arm64e`，即使命令行传了 `ARCHS=arm64`
也会被它顶掉。编译日志里应该能看到每个文件被编两遍：

```
==> Compiling Tweak.xm (arm64)…
==> Compiling Tweak.xm (arm64e)…
```

装完必须 respring（Dopamine 里点 Respring），否则 SpringBoard / 设置会继续用缓存的失败结果。

**已经改了 Makefile，装上去还是 incompatible architecture**
子工程 `prefs/` 是独立 make 进程，父工程的 `override ARCHS` 传不过去，
所以 `prefs/Makefile` 里也必须写一份：

```make
override ARCHS := arm64 arm64e
```

验证办法只有一个：装完在终端里看真实文件，而不是看设置页：

```sh
file /var/jb/Library/MobileSubstrate/DynamicLibraries/FolderIcon.dylib
file /var/jb/Library/PreferenceBundles/FolderIconsPrefs.bundle/FolderIconsPrefs
```

两行都要出现 `[arm64] [arm64e]`；只有 `[arm64]` 就说明装的还是旧包。

**Actions 里没有 Run workflow 按钮**
工作流文件必须在**默认分支**上，且路径严格是 `.github/workflows/build.yml`（注意开头那个点）。
另外：仓库如果刚创建还没 commit，Actions 页是空的。

**报 `unable to find SDK` / SDK 下载失败**
theos-action 第一次要下几百 MB SDK，网络抖动就会失败。重新 Run 一次即可（有缓存后不会再下）。

**报 `no such file or directory: FolderIcon/Makefile`**
源码层级放错了。仓库根目录下应该直接能看到 `FolderIcon/` 这个文件夹，而不是 `FolderIcon/src/FolderIcon/`。

**rootful 包装不上，提示架构不符**
CI 已经按 scheme 自动把 `control` 改成 `iphoneos-arm`（rootful）/ 保持 `iphoneos-arm64`（rootless）。如果你手动改过 control，注意同步。

**想改代码后重新出包**
方式 2（iSH/git）直接 push，Actions 会自动触发；方式 1 需要重新上传 tar.gz（同名覆盖会自动新 commit）。

# GitHub 调研记录

抓取时间：2026-11-20，通过 GitHub Search / Repos API（`sort=stars`）。
检索词：`folder icon customizer`、`folder icons`、`desktop folder`、`folder language:objective-c`、`SBFolderIconView`。

## 一、文件夹图标类（跨平台）

| 仓库 | 星标 | 语言 | 简介 |
|---|---:|---|---|
| [devblackops/Terminal-Icons](https://github.com/devblackops/Terminal-Icons) | 2960 | PowerShell | 在终端里给文件/文件夹显示图标 |
| [icon11-community/Folder11](https://github.com/icon11-community/Folder11) | 2027 | — | Windows 11 风格的自定义目录图标 |
| [lgarron/folderify](https://github.com/lgarron/folderify) | 1954 | Rust | 生成像素级贴合 macOS 原生风格的文件夹图标 |
| [gfxholo/iconic](https://github.com/gfxholo/iconic) | 902 | TypeScript | Obsidian 内给标签页/文件/文件夹/书签单独设图标和颜色 |
| [sameerasw/folder-icons](https://github.com/sameerasw/folder-icons) | 900 | Python | Windows 11 风格文件夹图标集 |
| [PapirusDevelopmentTeam/papirus-folders](https://github.com/PapirusDevelopmentTeam/papirus-folders) | 818 | Shell | 改 Papirus 图标主题里文件夹的配色 |
| [Bengerthelorf/macIconChanger](https://github.com/Bengerthelorf/macIconChanger) | 656 | Swift | macOS 换 app/文件夹图标，GUI + CLI，自动还原 |
| [mklement0/fileicon](https://github.com/mklement0/fileicon) | 551 | Shell | macOS 命令行管理文件/文件夹自定义图标 |
| [robb/FolderIconGenerator](https://github.com/robb/FolderIconGenerator) | 194 | Swift | 用 SF Symbols 生成 macOS 文件夹图标 |
| [aj-phillips/IconSwapperGui](https://github.com/aj-phillips/IconSwapperGui) | 22 | Python | Windows 批量换快捷方式/文件夹图标 |
| [kesai666/Desktop-folder](https://github.com/kesai666/Desktop-folder) | 4 | JavaScript | 在电脑桌面放一个「手机文件夹」小组件 |
| [sizwinz/FolderPainter](https://github.com/sizwinz/FolderPainter) | 3 | — | Tauri 2 写的 Windows 文件夹图标工作室 |

## 二、iOS 侧

| 仓库 | 星标 | 语言 | 简介 |
|---|---:|---|---|
| [jwilling/JWFolders](https://github.com/jwilling/JWFolders) | 635 | Objective-C | iOS 6 时代文件夹视图的开源实现 |
| [AdrienRL1/AppDrop](https://github.com/AdrienRL1/AppDrop) | 115 | — | 越狱设备上的应用浏览/安装工具（非文件夹图标） |
| [fabiocaccamo/FCFileManager](https://github.com/fabiocaccamo/FCFileManager) | 905 | Objective-C | 文件管理封装（与图标无关，检索噪声） |

结论：**开源且直接做「iOS 桌面文件夹自定义图标」的仓库几乎没有**——这一块要么是付费闭源插件（Bolders 一类），
要么是主题引擎（SnowBoard）里顺带换文件夹皮肤。检索 `folder tweak jailbreak` 只返回 1 个仓库，还是 Files.app 相关。

## 三、可复用的做法（已落到 FolderIcon 的实现里）

1. **名称 → 图标的映射表**（Terminal-Icons / sameerasw / folderify）
   → 用文件夹显示名做 key，用户可理解、可手动放文件、可脚本批量生成。
2. **先预处理再贴图**（folderify）
   → 居中裁切 + 等比填满 + 连续曲率圆角 + 统一 360px 画布。
3. **面板内选图、即时生效**（iconic）
   → PHPicker + Darwin notification 通知 SpringBoard 重绘，不用注销。
4. **非破坏性 + 可还原**（macIconChanger）
   → 只改视图层；单条左滑还原、全局一键重置。
5. **命令行/文件兜底通道**（fileicon）
   → `/var/mobile/Library/FolderIcons/<文件夹名>.png`，批量导入不用点 UI。

## 四、被否掉的方向

| 方向 | 为什么没做 |
|---|---|
| 直接改 IconState.plist 里的文件夹图标 | 会破坏系统图标状态，升级/还原易出问题，且需要 respring |
| 替换 SpringBoard 资源包里的 FolderIcon 图片 | 全局生效、无法按文件夹区分，且被主题引擎抢管 |
| 做成 SnowBoard 主题 | 依赖额外引擎，安装门槛高，不能「单独给某个文件夹设图」 |
| Hook `SBIconModel` 修改图标数据 | 影响面太大（Dock、搜索、资源库都走它），崩了就是白苹果级问题 |

//
//  FolderIconsPrefs.mm
//  FolderIcon 设置面板（PreferenceBundle）
//
//  说明：这里刻意不依赖 Preferences 私有头文件（PSSpecifier/PSListController），
//  整个面板就是一个普通 UIViewController + UITableView，由 PreferenceLoader
//  通过 entry plist 的 detail 字段直接实例化并 push 进「设置」的导航栈。
//  好处：少依赖一个私有 SDK，编译通过率更高；坏处：样式需要自己写。
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <PhotosUI/PhotosUI.h>
#import <notify.h>

static NSString *const kFCDomain      = @"com.dsh.foldericon";
static NSString *const kFCVersion     = @"1.0.0";
static NSString *const kFCImageDir    = @"/var/mobile/Library/FolderIcons";
static NSString *const kFCIconState   = @"/var/mobile/Library/SpringBoard/IconState.plist";

#pragma mark - 偏好读写

static id FCPref(NSString *key) {
    return (__bridge_transfer id)CFPreferencesCopyAppValue((__bridge CFStringRef)key,
                                                           (__bridge CFStringRef)kFCDomain);
}

static void FCSetPref(NSString *key, id value) {
    CFPreferencesSetAppValue((__bridge CFStringRef)key,
                             (__bridge CFPropertyListRef)value,
                             (__bridge CFStringRef)kFCDomain);
    CFPreferencesAppSynchronize((__bridge CFStringRef)kFCDomain);
}

/// 通知 SpringBoard 重新读取配置并即时重绘（无需 respring）
static void FCPostReload(void) {
    notify_post("com.dsh.foldericon/reload");
}

#pragma mark - 图片处理

/// 居中裁切 + 等比填满，输出 px×px 的方图（不烘焙圆角，交给运行时做连续曲率遮罩）
static UIImage *FCProcessImage(UIImage *source, CGFloat px) {
    if (!source) return nil;
    CGSize size = source.size;
    if (size.width < 1.0 || size.height < 1.0) return nil;

    UIGraphicsBeginImageContextWithOptions(CGSizeMake(px, px), NO, 1.0);
    CGFloat scale = MAX(px / size.width, px / size.height);
    CGRect rect = CGRectMake((px - size.width * scale) * 0.5,
                             (px - size.height * scale) * 0.5,
                             size.width * scale,
                             size.height * scale);
    [source drawInRect:rect];
    UIImage *result = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return result;
}

#pragma mark - 数据层

@interface FCStore : NSObject
+ (BOOL)enabled;
+ (void)setEnabled:(BOOL)value;

+ (NSInteger)mode;
+ (void)setMode:(NSInteger)value;

+ (CGFloat)scale;
+ (void)setScale:(CGFloat)value;

+ (CGFloat)radius;
+ (void)setRadius:(CGFloat)value;

+ (BOOL)debug;
+ (void)setDebug:(BOOL)value;

+ (NSDictionary<NSString *, NSData *> *)icons;
+ (NSData *)imageDataForName:(NSString *)name;
+ (void)setImageData:(NSData *)data forName:(NSString *)name;
+ (void)removeIconForName:(NSString *)name;
+ (void)resetAll;

+ (NSArray<NSString *> *)folderNames;
+ (void)addFolderName:(NSString *)name;

// 内部使用，写在接口里避免「方法未声明」告警
+ (void)rememberName:(NSString *)name;
+ (void)collectFromObject:(id)obj into:(NSMutableArray<NSString *> *)out depth:(NSInteger)depth;
+ (NSArray<NSString *> *)namesFromIconState;
@end

@implementation FCStore

+ (BOOL)enabled {
    id v = FCPref(@"Enabled");
    return v ? [v boolValue] : YES;
}

+ (void)setEnabled:(BOOL)value {
    FCSetPref(@"Enabled", @(value));
}

+ (NSInteger)mode {
    id v = FCPref(@"Mode");
    return v ? [v integerValue] : 0;
}

+ (void)setMode:(NSInteger)value {
    FCSetPref(@"Mode", @(value));
}

+ (CGFloat)scale {
    id v = FCPref(@"Scale");
    CGFloat f = v ? [v doubleValue] : 1.0;
    return (f >= 0.4 && f <= 1.0) ? f : 1.0;
}

+ (void)setScale:(CGFloat)value {
    FCSetPref(@"Scale", @(value));
}

+ (CGFloat)radius {
    id v = FCPref(@"Radius");
    CGFloat f = v ? [v doubleValue] : 0.2237;
    return (f >= 0.0 && f <= 0.5) ? f : 0.2237;
}

+ (void)setRadius:(CGFloat)value {
    FCSetPref(@"Radius", @(value));
}

+ (BOOL)debug {
    id v = FCPref(@"Debug");
    return v ? [v boolValue] : NO;
}

+ (void)setDebug:(BOOL)value {
    FCSetPref(@"Debug", @(value));
}

+ (NSDictionary<NSString *, NSData *> *)icons {
    id v = FCPref(@"Icons");
    return [v isKindOfClass:[NSDictionary class]] ? (NSDictionary *)v : @{};
}

+ (NSData *)imageDataForName:(NSString *)name {
    if (name.length == 0) return nil;
    id data = [self icons][name];
    return [data isKindOfClass:[NSData class]] ? (NSData *)data : nil;
}

+ (void)setImageData:(NSData *)data forName:(NSString *)name {
    if (name.length == 0 || data.length == 0) return;
    NSMutableDictionary *dict = [[self icons] mutableCopy];
    dict[name] = data;
    FCSetPref(@"Icons", dict);
    [self rememberName:name];
}

+ (void)removeIconForName:(NSString *)name {
    if (name.length == 0) return;
    NSMutableDictionary *dict = [[self icons] mutableCopy];
    [dict removeObjectForKey:name];
    FCSetPref(@"Icons", dict);
}

+ (void)resetAll {
    FCSetPref(@"Icons", @{});
}

+ (void)rememberName:(NSString *)name {
    if (name.length == 0) return;
    id v = FCPref(@"Folders");
    NSMutableArray *list = [v isKindOfClass:[NSArray class]] ? [(NSArray *)v mutableCopy] : [NSMutableArray array];
    if ([list containsObject:name]) return;
    [list addObject:name];
    FCSetPref(@"Folders", list);
}

+ (void)addFolderName:(NSString *)name {
    [self rememberName:name];
}

/// 递归解析 IconState.plist，把「有 displayName 且有 iconLists」的字典视为文件夹。
/// 读不到（沙箱/路径变化）就返回空数组，面板仍有插件回写的 Folders 列表兜底。
+ (void)collectFromObject:(id)obj into:(NSMutableArray<NSString *> *)out depth:(NSInteger)depth {
    if (depth > 12 || obj == nil) return;
    if ([obj isKindOfClass:[NSDictionary class]]) {
        NSDictionary *dict = (NSDictionary *)obj;
        id displayName = dict[@"displayName"];
        id iconLists   = dict[@"iconLists"];
        if ([displayName isKindOfClass:[NSString class]] && iconLists != nil) {
            [out addObject:(NSString *)displayName];
        }
        for (id value in [dict allValues]) {
            [self collectFromObject:value into:out depth:depth + 1];
        }
    } else if ([obj isKindOfClass:[NSArray class]]) {
        for (id value in (NSArray *)obj) {
            [self collectFromObject:value into:out depth:depth + 1];
        }
    }
}

+ (NSArray<NSString *> *)namesFromIconState {
    NSMutableArray<NSString *> *out = [NSMutableArray array];
    NSData *data = [NSData dataWithContentsOfFile:kFCIconState];
    if (!data) return out;
    id plist = [NSPropertyListSerialization propertyListWithData:data
                                                         options:NSPropertyListImmutable
                                                          format:NULL
                                                           error:NULL];
    if (plist) [self collectFromObject:plist into:out depth:0];
    return out;
}

+ (NSArray<NSString *> *)folderNames {
    NSMutableOrderedSet<NSString *> *set = [NSMutableOrderedSet new];

    id v = FCPref(@"Folders");
    if ([v isKindOfClass:[NSArray class]]) {
        for (id name in (NSArray *)v) {
            if ([name isKindOfClass:[NSString class]] && [(NSString *)name length] > 0) {
                [set addObject:name];
            }
        }
    }

    for (NSString *name in [self namesFromIconState]) {
        if (name.length) [set addObject:name];
    }

    for (NSString *name in [self icons]) {
        [set addObject:name];
    }

    NSArray *sorted = [set.array sortedArrayUsingSelector:@selector(localizedStandardCompare:)];
    return sorted;
}

@end

#pragma mark - 文件夹行 Cell

@interface FCFolderCell : UITableViewCell
@property (nonatomic, strong) UIImageView *iconView;
@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UILabel *statusLabel;
- (void)configureWithName:(NSString *)name image:(UIImage *)image configured:(BOOL)configured;
@end

@implementation FCFolderCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    if (self) {
        self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        self.selectionStyle = UITableViewCellSelectionStyleDefault;

        _iconView = [[UIImageView alloc] initWithFrame:CGRectZero];
        _iconView.contentMode = UIViewContentModeScaleAspectFill;
        _iconView.clipsToBounds = YES;
        _iconView.layer.cornerRadius = 9.0;
        _iconView.layer.cornerCurve = kCACornerCurveContinuous;
        _iconView.layer.borderWidth = 0.5;
        _iconView.layer.borderColor = [UIColor separatorColor].CGColor;
        _iconView.backgroundColor = [UIColor tertiarySystemFillColor];
        [self.contentView addSubview:_iconView];

        _nameLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _nameLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        _nameLabel.textColor = [UIColor labelColor];
        [self.contentView addSubview:_nameLabel];

        _statusLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _statusLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleCaption1];
        _statusLabel.textColor = [UIColor secondaryLabelColor];
        [self.contentView addSubview:_statusLabel];
    }
    return self;
}

- (void)configureWithName:(NSString *)name image:(UIImage *)image configured:(BOOL)configured {
    self.nameLabel.text = name;
    self.iconView.image = image;
    self.statusLabel.text = configured ? @"自定义图标" : @"默认图标（点按选择图片）";
    self.statusLabel.textColor = configured ? [UIColor systemBlueColor] : [UIColor secondaryLabelColor];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGRect bounds = self.contentView.bounds;
    CGFloat side = 40.0;
    self.iconView.frame = CGRectMake(16.0, (bounds.size.height - side) * 0.5, side, side);

    CGFloat x = CGRectGetMaxX(self.iconView.frame) + 12.0;
    CGFloat width = bounds.size.width - x - 40.0;
    self.nameLabel.frame = CGRectMake(x, bounds.size.height * 0.5 - 21.0, width, 22.0);
    self.statusLabel.frame = CGRectMake(x, bounds.size.height * 0.5 + 1.0, width, 16.0);
}

@end

#pragma mark - 设置面板

typedef NS_ENUM(NSInteger, FCSection) {
    FCSectionGeneral = 0,
    FCSectionFolders,
    FCSectionActions,
    FCSectionCount
};

@interface FolderIconsRootController : UIViewController <UITableViewDataSource, UITableViewDelegate, PHPickerViewControllerDelegate, UIDocumentPickerDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, copy)   NSArray<NSString *> *folders;
@property (nonatomic, copy)   NSString *pendingFolderName;
@end

@interface FolderIconsRootController (ImagePicking)
- (void)loadImageFromProvider:(NSItemProvider *)provider
                   completion:(void (^)(UIImage *image, NSError *error))completion;
- (void)loadImageDataFromProvider:(NSItemProvider *)provider
                       completion:(void (^)(UIImage *image, NSError *error))completion;
- (void)tryLoadProvider:(NSItemProvider *)provider
                  types:(NSArray<NSString *> *)types
                  index:(NSUInteger)index
             completion:(void (^)(UIImage *image, NSError *error))completion;
@end

@implementation FolderIconsRootController

#pragma mark - PreferenceLoader 兼容
// PreferenceLoader 可能把 detail 控制器当作 PSViewController 来配置，
// 我们是纯 UIViewController，把这些消息吞掉，避免 unrecognized selector。

- (void)setSpecifier:(id)specifier {}
- (void)setRootController:(id)controller {}
- (void)setParentController:(id)controller {}
- (void)setPreferenceValue:(id)value specifier:(id)specifier {}
- (void)setProperty:(id)value forKey:(id)key {}
- (id)propertyForKey:(id)key { return nil; }

- (instancetype)init {
    self = [super init];
    if (self) {
        _folders = @[];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"文件夹图标";
    self.view.backgroundColor = [UIColor systemGroupedBackgroundColor];

    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleInsetGrouped];
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.backgroundColor = [UIColor systemGroupedBackgroundColor];
    [self.tableView registerClass:[FCFolderCell class] forCellReuseIdentifier:@"FCFolderCell"];
    [self.view addSubview:self.tableView];

    [self reloadData];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self reloadData];
}

- (void)reloadData {
    self.folders = [FCStore folderNames];
    [self.tableView reloadData];
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return FCSectionCount;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case FCSectionGeneral: return 5;
        case FCSectionFolders: return self.folders.count + 1;
        case FCSectionActions: return 2;
        default: return 0;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    switch (section) {
        case FCSectionGeneral: return @"外观";
        case FCSectionFolders: return @"文件夹";
        case FCSectionActions: return @"维护";
        default: return nil;
    }
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    if (section == FCSectionGeneral) {
        return @"「覆盖」会用你的图片替换整个文件夹图标；「叠加」保留系统文件夹底色，把图片叠在上面。改完立刻生效，不需要注销。";
    }
    if (section == FCSectionFolders) {
        return [NSString stringWithFormat:@"图标按「文件夹显示名」保存（%@ 个）。给文件夹改名后需要重新设置。\n高级用法：把 PNG 命名为「文件夹名.png」放进 %@，效果相同。",
                @(self.folders.count), kFCImageDir];
    }
    if (section == FCSectionActions) {
        return [NSString stringWithFormat:@"FolderIcon %@ · 适用于 iOS 14–16 的越狱环境（rootful / rootless 均可）", kFCVersion];
    }
    return nil;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.section) {
        case FCSectionGeneral:
            return [self generalCellForRow:indexPath.row];

        case FCSectionFolders:
            if (indexPath.row >= (NSInteger)self.folders.count) {
                UITableViewCell *cell = [self plainCellWithIdentifier:@"FCAddCell"];
                cell.textLabel.text = @"手动添加文件夹名…";
                cell.textLabel.textColor = [UIColor systemBlueColor];
                cell.accessoryType = UITableViewCellAccessoryNone;
                return cell;
            }
            return [self folderCellForRow:indexPath.row];

        default: {
            UITableViewCell *cell = [self plainCellWithIdentifier:@"FCActionCell"];
            if (indexPath.row == 0) {
                cell.textLabel.text = @"立即刷新桌面图标";
                cell.textLabel.textColor = [UIColor systemBlueColor];
            } else {
                cell.textLabel.text = @"全部恢复默认";
                cell.textLabel.textColor = [UIColor systemRedColor];
            }
            return cell;
        }
    }
}

#pragma mark - Cell 构造

- (UITableViewCell *)plainCellWithIdentifier:(NSString *)identifier {
    UITableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        // Value1 才有 detailTextLabel：滑杆数值就显示在那里
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    }
    cell.accessoryView = nil;
    cell.accessoryType = UITableViewCellAccessoryNone;
    cell.imageView.image = nil;
    cell.selectionStyle = UITableViewCellSelectionStyleDefault;
    cell.textLabel.textColor = [UIColor labelColor];
    cell.detailTextLabel.text = nil;
    return cell;
}

- (UITableViewCell *)generalCellForRow:(NSInteger)row {
    UITableViewCell *cell = [self plainCellWithIdentifier:[NSString stringWithFormat:@"FCGeneral%ld", (long)row]];

    if (row == 0) {
        cell.textLabel.text = @"启用";
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        UISwitch *toggle = [[UISwitch alloc] init];
        toggle.on = [FCStore enabled];
        [toggle addTarget:self action:@selector(toggleEnabled:) forControlEvents:UIControlEventValueChanged];
        cell.accessoryView = toggle;
        return cell;
    }

    if (row == 1) {
        cell.textLabel.text = @"渲染模式";
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        UISegmentedControl *seg = [[UISegmentedControl alloc] initWithItems:@[@"覆盖", @"叠加"]];
        seg.selectedSegmentIndex = [FCStore mode] == 1 ? 1 : 0;
        [seg addTarget:self action:@selector(changeMode:) forControlEvents:UIControlEventValueChanged];
        cell.accessoryView = seg;
        return cell;
    }

    if (row == 2) {
        cell.textLabel.text = @"图标大小";
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        UISlider *slider = [[UISlider alloc] initWithFrame:CGRectMake(0, 0, 150, 32)];
        slider.minimumValue = 0.6f;
        slider.maximumValue = 1.0f;
        slider.value = (float)[FCStore scale];
        slider.tag = 0x5101;
        [slider addTarget:self action:@selector(changeScale:) forControlEvents:UIControlEventValueChanged];
        cell.accessoryView = slider;
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%d%%", (int)lroundf(slider.value * 100)];
        return cell;
    }

    if (row == 3) {
        cell.textLabel.text = @"圆角";
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        UISlider *slider = [[UISlider alloc] initWithFrame:CGRectMake(0, 0, 150, 32)];
        slider.minimumValue = 0.0f;
        slider.maximumValue = 0.5f;
        slider.value = (float)[FCStore radius];
        slider.tag = 0x5102;
        [slider addTarget:self action:@selector(changeRadius:) forControlEvents:UIControlEventValueChanged];
        cell.accessoryView = slider;
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%.2f", slider.value];
        return cell;
    }

    // row == 4：调试日志
    cell.textLabel.text = @"记录调试日志";
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    UISwitch *debugSwitch = [[UISwitch alloc] init];
    debugSwitch.on = [FCStore debug];
    [debugSwitch addTarget:self action:@selector(toggleDebug:) forControlEvents:UIControlEventValueChanged];
    cell.accessoryView = debugSwitch;
    return cell;
}

- (UITableViewCell *)folderCellForRow:(NSInteger)row {
    FCFolderCell *cell = [self.tableView dequeueReusableCellWithIdentifier:@"FCFolderCell"];
    NSString *name = self.folders[row];
    NSData *data = [FCStore imageDataForName:name];
    UIImage *thumb = nil;
    if (data.length) {
        thumb = [UIImage imageWithData:data scale:[UIScreen mainScreen].scale];
        if (!thumb) {
            NSString *file = [kFCImageDir stringByAppendingPathComponent:
                              [name stringByAppendingPathExtension:@"png"]];
            thumb = [UIImage imageWithContentsOfFile:file];
        }
    }
    [cell configureWithName:name image:thumb configured:(thumb != nil)];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.selectionStyle = UITableViewCellSelectionStyleDefault;
    return cell;
}

#pragma mark - 交互

- (void)toggleEnabled:(UISwitch *)sender {
    [FCStore setEnabled:sender.isOn];
    FCPostReload();
}

- (void)toggleDebug:(UISwitch *)sender {
    [FCStore setDebug:sender.isOn];
    FCPostReload();
    if (sender.isOn) {
        [self toast:@"已开启。用 log stream 过滤 FolderIcon 查看日志"];
    }
}

- (void)changeMode:(UISegmentedControl *)sender {
    [FCStore setMode:sender.selectedSegmentIndex == 1 ? 1 : 0];
    FCPostReload();
}

- (void)changeScale:(UISlider *)sender {
    [FCStore setScale:sender.value];
    FCPostReload();
    [self refreshValueLabels];
}

- (void)changeRadius:(UISlider *)sender {
    [FCStore setRadius:sender.value];
    FCPostReload();
    [self refreshValueLabels];
}

/// 滑杆数值是 cell.detailTextLabel 显示的，重载整表会打断拖动，这里只更新文字
- (void)refreshValueLabels {
    for (UITableViewCell *cell in self.tableView.visibleCells) {
        if ([cell.accessoryView isKindOfClass:[UISlider class]]) {
            UISlider *slider = (UISlider *)cell.accessoryView;
            if (slider.tag == 0x5101) {
                cell.detailTextLabel.text = [NSString stringWithFormat:@"%d%%", (int)lroundf(slider.value * 100)];
            } else if (slider.tag == 0x5102) {
                cell.detailTextLabel.text = [NSString stringWithFormat:@"%.2f", slider.value];
            }
        }
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];

    if (indexPath.section == FCSectionFolders) {
        if (indexPath.row >= (NSInteger)self.folders.count) {
            [self promptForFolderName];
        } else {
            [self presentSourceSheetForFolder:self.folders[indexPath.row]];
        }
        return;
    }

    if (indexPath.section == FCSectionActions) {
        if (indexPath.row == 0) {
            FCPostReload();
            [self toast:@"已请求 SpringBoard 刷新"];
        } else {
            [self confirmReset];
        }
    }
}

- (UISwipeActionsConfiguration *)tableView:(UITableView *)tableView trailingSwipeActionsConfigurationForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section != FCSectionFolders || indexPath.row >= (NSInteger)self.folders.count) {
        return nil;
    }
    NSString *name = self.folders[indexPath.row];
    if ([FCStore imageDataForName:name] == nil) {
        return nil;
    }
    __weak typeof(self) weakSelf = self;
    UIContextualAction *action = [UIContextualAction contextualActionWithStyle:UIContextualActionStyleDestructive
                                                                         title:@"恢复默认"
                                                                       handler:^(UIContextualAction *a, UIView *view, void (^done)(BOOL)) {
        [FCStore removeIconForName:name];
        FCPostReload();
        [weakSelf reloadData];
        done(YES);
    }];
    return [UISwipeActionsConfiguration configurationWithActions:@[action]];
}

#pragma mark - 选图

/// 点文件夹先问来源：相册 / 文件 App / （已设置时）恢复默认
- (void)presentSourceSheetForFolder:(NSString *)name {
    self.pendingFolderName = name;

    BOOL hasIcon = [FCStore imageDataForName:name] != nil;

    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:name
                                                                   message:@"选择图标来源"
                                                            preferredStyle:UIAlertControllerStyleActionSheet];

    __weak typeof(self) weakSelf = self;
    [sheet addAction:[UIAlertAction actionWithTitle:@"从相册选择" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        // 等 sheet 收完再 present，避免「presenting while dismissing」
        dispatch_async(dispatch_get_main_queue(), ^{ [weakSelf presentPickerForFolder:name]; });
    }]];

    [sheet addAction:[UIAlertAction actionWithTitle:@"从「文件」选择" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        dispatch_async(dispatch_get_main_queue(), ^{ [weakSelf presentDocumentPickerForFolder:name]; });
    }]];

    // 「设置」进程里 PHPicker 的 NSItemProvider 常常取不到数据
    // （Cannot load representation of type public.jpeg），
    // 剪贴板是同一进程内最可靠的一条通道：照片 App 里长按 → 拷贝 → 这里粘贴。
    [sheet addAction:[UIAlertAction actionWithTitle:@"粘贴剪贴板里的图片" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        UIImage *pasted = [UIPasteboard generalPasteboard].image;
        if (pasted) {
            [weakSelf applyImage:pasted forFolder:name];
        } else {
            [weakSelf toast:@"剪贴板里没有图片。请到「照片」长按照片→拷贝，再回来粘贴"];
        }
    }]];

    if (hasIcon) {
        [sheet addAction:[UIAlertAction actionWithTitle:@"恢复默认图标" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
            [FCStore removeIconForName:name];
            FCPostReload();
            [weakSelf reloadData];
            [weakSelf toast:[NSString stringWithFormat:@"「%@」已恢复默认", name]];
        }]];
    }

    [sheet addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];

    sheet.popoverPresentationController.sourceView = self.view;
    sheet.popoverPresentationController.sourceRect = CGRectMake(self.view.bounds.size.width * 0.5,
                                                               self.view.bounds.size.height * 0.5, 1, 1);
    [self presentViewController:sheet animated:YES completion:nil];
}

- (void)presentPickerForFolder:(NSString *)name {
    self.pendingFolderName = name;

    PHPickerConfiguration *config = [[PHPickerConfiguration alloc] init];
    config.filter = [PHPickerFilter imagesFilter];
    config.selectionLimit = 1;
    // PHPicker 走独立进程，设置面板不需要相册权限声明
    PHPickerViewController *picker = [[PHPickerViewController alloc] initWithConfiguration:config];
    picker.delegate = self;
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)presentDocumentPickerForFolder:(NSString *)name {
    self.pendingFolderName = name;

    // public.image 覆盖 png/jpg/heic，iOS 14 上仍可用（新 API 要 UTType，没必要为此抬依赖）
    UIDocumentPickerViewController *picker =
        [[UIDocumentPickerViewController alloc] initWithDocumentTypes:@[@"public.image"]
                                                              inMode:UIDocumentPickerModeImport];
    picker.delegate = self;
    picker.allowsMultipleSelection = NO;
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)picker:(PHPickerViewController *)picker didFinishPicking:(NSArray<PHPickerResult *> *)results {
    NSString *name = self.pendingFolderName;
    self.pendingFolderName = nil;

    if (results.count == 0 || name.length == 0) {
        [picker dismissViewControllerAnimated:YES completion:nil];
        return;
    }

    NSItemProvider *provider = results.firstObject.itemProvider;
    __weak typeof(self) weakSelf = self;

    // 注意：先取图、取完再 dismiss。先 dismiss 会让 provider 的临时资源失效。
    [self loadImageFromProvider:provider completion:^(UIImage *image, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [picker dismissViewControllerAnimated:YES completion:nil];
            if (!image) {
                NSString *reason = error.localizedDescription;
                [weakSelf toast:(reason.length
                    ? [NSString stringWithFormat:@"读取失败：%@", reason]
                    : @"这条读不出图片（iCloud 未下载的原图常见）")];
                return;
            }
            [weakSelf applyImage:image forFolder:name];
        });
    }];
}

#pragma mark - 从 NSItemProvider 取图（三级降级）

/// 相册里的条目经常不能直接 loadObjectOfClass:[UIImage class]：
/// iCloud 未下载的原图、HEIC、Live Photo 都会返回 nil，
/// 只写这一条路径就是「没有读到图片」的根因。
/// 这里按 1→2→3 依次降级。
- (void)loadImageFromProvider:(NSItemProvider *)provider
                   completion:(void (^)(UIImage *image, NSError *error))completion {
    if (!provider) { completion(nil, nil); return; }

    if ([provider canLoadObjectOfClass:[UIImage class]]) {
        [provider loadObjectOfClass:[UIImage class] completionHandler:^(id<NSItemProviderReading> object, NSError *error) {
            if ([object isKindOfClass:[UIImage class]]) {
                completion((UIImage *)object, nil);
                return;
            }
            [self loadImageDataFromProvider:provider completion:completion];
        }];
        return;
    }

    [self loadImageDataFromProvider:provider completion:completion];
}

- (void)loadImageDataFromProvider:(NSItemProvider *)provider
                       completion:(void (^)(UIImage *image, NSError *error))completion {
    // 把 provider 自报的「图片类」标识符全部挑出来逐个试。
    // 只请求 public.image 时，系统会解析成 public.jpeg 再失败
    // （Cannot load representation of type public.jpeg）；
    // 直接请求它自己声明的精确类型，成功率更高。
    NSMutableArray<NSString *> *types = [NSMutableArray array];
    for (NSString *type in provider.registeredTypeIdentifiers) {
        NSString *lower = type.lowercaseString;
        if ([lower containsString:@"image"] || [lower containsString:@"jpeg"] ||
            [lower containsString:@"png"]   || [lower containsString:@"heic"] ||
            [lower containsString:@"heif"]  || [lower containsString:@"tiff"] ||
            [lower containsString:@"gif"]   || [lower containsString:@"webp"]) {
            if (![types containsObject:type]) [types addObject:type];
        }
    }
    if (![types containsObject:@"public.image"]) [types addObject:@"public.image"];

    [self tryLoadProvider:provider types:types index:0 completion:completion];
}

- (void)tryLoadProvider:(NSItemProvider *)provider
                  types:(NSArray<NSString *> *)types
                  index:(NSUInteger)index
             completion:(void (^)(UIImage *image, NSError *error))completion {
    if (index >= types.count) {
        completion(nil, [NSError errorWithDomain:@"FolderIcon"
                                            code:1
                                        userInfo:@{NSLocalizedDescriptionKey:
                                            @"这张取不到数据，请改用「文件」或「剪贴板」"}]);
        return;
    }

    NSString *type = types[index];
    __weak typeof(self) weakSelf = self;

    [provider loadDataRepresentationForTypeIdentifier:type completionHandler:^(NSData *data, NSError *dataError) {
        if (data.length > 0) {
            UIImage *image = [UIImage imageWithData:data];
            if (image) { completion(image, nil); return; }
        }

        [provider loadFileRepresentationForTypeIdentifier:type completionHandler:^(NSURL *url, NSError *fileError) {
            // url 只在本次回调内有效，必须立刻读成 NSData
            if (url) {
                NSData *fileData = [NSData dataWithContentsOfURL:url];
                UIImage *image = fileData.length ? [UIImage imageWithData:fileData] : nil;
                if (image) { completion(image, nil); return; }
            }
            [weakSelf tryLoadProvider:provider types:types index:index + 1 completion:completion];
        }];
    }];
}

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSString *name = self.pendingFolderName;
    self.pendingFolderName = nil;

    NSURL *url = urls.firstObject;
    if (!url || name.length == 0) return;

    BOOL scoped = [url startAccessingSecurityScopedResource];
    NSData *data = [NSData dataWithContentsOfURL:url];
    if (scoped) [url stopAccessingSecurityScopedResource];

    UIImage *image = data ? [UIImage imageWithData:data] : nil;
    [self applyImage:image forFolder:name];
}

- (void)documentPickerWasCancelled:(UIDocumentPickerViewController *)controller {
    self.pendingFolderName = nil;
}

/// 统一入口：裁切 → 360px PNG → 写偏好 → 通知 SpringBoard
- (void)applyImage:(UIImage *)image forFolder:(NSString *)name {
    if (!image || name.length == 0) {
        [self toast:@"没有读到图片"];
        return;
    }
    UIImage *processed = FCProcessImage(image, 360.0);
    NSData *png = processed ? UIImagePNGRepresentation(processed) : nil;
    if (png.length == 0) {
        [self toast:@"图片转换失败"];
        return;
    }
    [FCStore setImageData:png forName:name];
    FCPostReload();
    [self reloadData];
    [self toast:[NSString stringWithFormat:@"已设置「%@」", name]];
}

#pragma mark - 其它操作

- (void)promptForFolderName {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"添加文件夹名"
                                                                   message:@"输入桌面文件夹的显示名，用于手动挂载已准备好的图标。"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.placeholder = @"例如：游戏";
    }];
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:@"添加" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSString *name = alert.textFields.firstObject.text;
        if (name.length == 0) return;
        [FCStore addFolderName:name];
        [weakSelf reloadData];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)confirmReset {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"全部恢复默认"
                                                                   message:@"将删除所有已设置的分文件夹图标，系统文件夹图标会立即还原。"
                                                            preferredStyle:UIAlertControllerStyleActionSheet];
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:@"确认删除" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        [FCStore resetAll];
        FCPostReload();
        [weakSelf reloadData];
        [weakSelf toast:@"已全部恢复默认"];
    }]];
    // iPad / 横屏下 actionSheet 需要锚点
    alert.popoverPresentationController.sourceView = self.view;
    alert.popoverPresentationController.sourceRect = CGRectMake(self.view.bounds.size.width * 0.5,
                                                               self.view.bounds.size.height * 0.5, 1, 1);
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)toast:(NSString *)message {
    if (message.length == 0) return;
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil
                                                                   message:message
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [self presentViewController:alert animated:YES completion:nil];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [alert dismissViewControllerAnimated:YES completion:nil];
    });
}

@end
